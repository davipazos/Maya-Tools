"""

## License & Copyright

This script is free to use in personal, student, and commercial projects.

You may share or redistribute it (including modified versions), as long as proper credit is given to the original author.
A link back to the Gumroad page is appreciated when possible.

© 2025 davipazos3d. All rights reserved.

"""

import maya.cmds as cmds
import os

def import_library():
    # Path to the library file
    library_path = r""  # Provide the file path here

    if os.path.exists(library_path):
        cmds.file(
            library_path,
            i=True,
            type="mayaBinary",
            ignoreVersion=True,
            mergeNamespacesOnClash=False,
            rpr="Library"
        )
        print(f"Library imported from: {library_path}")
    else:
        print(f"File not found at: {library_path}")

import_library()