# Import Library File

This script allows you to import a custom Maya library (binary file) into your current scene. It's useful for quickly loading a set of pre-designed elements. You can run a file with just one click.

## How to Use

1. Set the `library_path` variable in the script to the full path of your `.mb` library file.
2. Run the script in Maya's Script Editor or Python tab.
3. The file will be imported.

## Example

library_path = r"C:\\Users\\YourUser\\Documents\\maya\\projects\\default\\scenes\\myControls.mb"
