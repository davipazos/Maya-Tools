# Proxy Attribute Tool for Maya

## Overview

The tool is a simple script for Autodesk Maya that allows you to easily create proxy attributes. A proxy attribute on one control (the "destination") will mirror an attribute from another control (the "source"). This is useful for rigging, allowing you to centralize control over complex setups and improve animator workflows.

## Features

-Clean, Simple UI: Easily select source and destination controls and type the attribute name.
-Fast Proxy Creation: Create proxy attributes instantly—no coding or node digging required.
-Safe & Smart: Built-in error handling and visual confirmation in the viewport.

## How to Install

1. Download the Script: Get the proxyAttributeTool.py file from this Gumroad page.

2. Optional Installation (Recommended for Reuse):
	-Open Maya.
	-Go to Script Editor → Paste the code.
	-Save it to your shelf using File > Save Script to Shelf (Python).
OR
	-Copy the file into your Maya scripts folder:
	-Windows: C:\Users\[YourUser]\Documents\maya\[MayaVersion]\scripts\
	-macOS: ~/Library/Preferences/Autodesk/maya/[MayaVersion]/scripts/
	-Linux: ~/maya/[MayaVersion]/scripts/
	-Restart Maya or source the script manually if needed.

## How to Use

1. Set It Up:

	-Source (Control with Attribute): Select the object with the attribute you want to link from and click "Add".
	-Destination (Proxy Control): Select the object where you want to create the proxy and click "Add".
	-Attribute Name: Type the name of the attribute (e.g., jawOpen, browRaise).
	-Click Create Proxy.
Done!
	-Maya will confirm in the viewport with a message like: Proxy created: ctl_main.jawOpen -> ctl_face.jawOpen

## Troubleshooting

-Nothing happens? Make sure both source and destination fields are filled and valid.
-Wrong attribute? Double-check for typos or capitalization—Maya is case-sensitive.
-Error creating proxy? Ensure the attribute exists on the source object and is keyable.

## License & Copyright

This script is free to use in personal, student, and commercial projects.

You may share or redistribute it (including modified versions), as long as proper credit is given to the original author.
A link back to the Gumroad page is appreciated when possible.

© 2025 davipazos3d. All rights reserved.

## Contact

Got feedback, questions, or ideas for improvements?
Feel free to reach out via [davipazos3d@gmail.com].