"""

## License & Copyright

This script is free to use in personal, student, and commercial projects.

You may share or redistribute it (including modified versions), as long as proper credit is given to the original author.
A link back to the Gumroad page is appreciated when possible.

© 2025 davipazos3d. All rights reserved.

"""

import maya.cmds as cmds

class ProxyAttributeTool:
    def __init__(self):
        self.window = 'proxyAttrWindow'
        self.create_ui()

    def create_ui(self):
        if cmds.window(self.window, exists=True):
            cmds.deleteUI(self.window)

        self.window = cmds.window(self.window, title='Proxy Attr Tool', widthHeight=(300, 150))
        cmds.columnLayout(adjustableColumn=True, rowSpacing=10)

        cmds.text(label='Source (Control with Attribute)')
        self.source = cmds.textFieldButtonGrp(label='Select', buttonLabel='Add', bc=self.select_source)

        cmds.text(label='Destination (Proxy Control)')
        self.destination = cmds.textFieldButtonGrp(label='Select', buttonLabel='Add', bc=self.select_destination)

        cmds.text(label='Attribute Name')
        self.attribute = cmds.textField()

        cmds.button(label='Create Proxy', command=self.apply_proxy)
        cmds.showWindow(self.window)

    def select_source(self):
        """
        Populates the source text field with the currently selected object in Maya.
        """
        selection = cmds.ls(selection=True)
        if selection:
            cmds.textFieldButtonGrp(self.source, edit=True, text=selection[0])
        else:
            cmds.warning('Please select an object to add as source.')

    def select_destination(self):
        """
        Populates the destination text field with the currently selected object in Maya.
        """
        selection = cmds.ls(selection=True)
        if selection:
            cmds.textFieldButtonGrp(self.destination, edit=True, text=selection[0])
        else:
            cmds.warning('Please select an object to add as destination.')

    def apply_proxy(self, *_):
        source = cmds.textFieldButtonGrp(self.source, query=True, text=True)
        destination = cmds.textFieldButtonGrp(self.destination, query=True, text=True)
        attribute = cmds.textField(self.attribute, query=True, text=True)

        if source and destination and attribute:
            if cmds.objExists(source) and cmds.objExists(destination):
                try:
                    cmds.addAttr(destination, longName=attribute, proxy=f'{source}.{attribute}')
                    cmds.inViewMessage(amg=f'Proxy created: {destination}.{attribute} -> {source}.{attribute}', pos='midCenter', fade=True)
                except Exception as e:
                    cmds.warning(f'Error creating proxy: {e}')
            else:
                cmds.warning('One or both objects do not exist.')
        else:
            cmds.warning('Please fill in all fields.')

ProxyAttributeTool()