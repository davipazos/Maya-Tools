"""

## License & Copyright

This script is free to use in personal, student, and commercial projects.

You may share or redistribute it (including modified versions), as long as proper credit is given to the original author.
A link back to the Gumroad page is appreciated when possible.

© 2025 davipazos3d. All rights reserved.

"""

import maya.cmds as cmds

def create_mass_connection_tool():
    """Creates a UI to connect one attribute to multiple destination objects."""
    if cmds.window("MassConnectionTool", exists=True):
        cmds.deleteUI("MassConnectionTool")

    window = cmds.window("MassConnectionTool", title="Mass Attribute Connection Tool", widthHeight=(400, 300))
    cmds.columnLayout(adjustableColumn=True)

    cmds.text(label="Mass Attribute Connection Tool", height=40, bgc=[0.3, 0.6, 0.9], align="center")

    cmds.text(label="Source Object:")
    cmds.textFieldButtonGrp("sourceObjectField", label="Source:", buttonLabel="Select", 
                            buttonCommand=lambda: select_source_object())

    cmds.text(label="Source Attribute:")
    cmds.textField("sourceAttributeField", placeholderText="Example: visibility")

    cmds.text(label="Destination Object(s):")
    cmds.textScrollList("destinationObjectsList", allowMultiSelection=True, height=100)

    cmds.button(label="Add Selected Objects", command=lambda _: add_destination_objects(), bgc=[0.4, 0.7, 0.4])
    cmds.button(label="Remove Selected", command=lambda _: remove_selected_destination_objects(), bgc=[0.9, 0.4, 0.4])

    cmds.text(label="Destination Attribute:")
    cmds.textField("destinationAttributeField", placeholderText="Example: visibility")

    cmds.separator(height=10, style="in")
    cmds.button(label="Connect Attributes", command=lambda _: connect_attributes(), height=40, bgc=[0.2, 0.8, 0.5])

    cmds.showWindow(window)

def select_source_object():
    selection = cmds.ls(selection=True)
    if selection:
        cmds.textFieldButtonGrp("sourceObjectField", edit=True, text=selection[0])
    else:
        cmds.warning("Please select a source object.")

def add_destination_objects():
    selection = cmds.ls(selection=True)
    if selection:
        cmds.textScrollList("destinationObjectsList", edit=True, append=selection)
    else:
        cmds.warning("Select one or more objects to add as destinations.")

def remove_selected_destination_objects():
    selected_items = cmds.textScrollList("destinationObjectsList", query=True, selectItem=True)
    if selected_items:
        for item in selected_items:
            cmds.textScrollList("destinationObjectsList", edit=True, removeItem=item)
    else:
        cmds.warning("Select one or more objects from the list to remove.")

def connect_attributes():
    source_object = cmds.textFieldButtonGrp("sourceObjectField", query=True, text=True)
    source_attribute = cmds.textField("sourceAttributeField", query=True, text=True)
    destination_objects = cmds.textScrollList("destinationObjectsList", query=True, allItems=True)
    destination_attribute = cmds.textField("destinationAttributeField", query=True, text=True)

    if not source_object or not source_attribute:
        cmds.warning("Specify a source object and attribute.")
        return
    if not destination_objects:
        cmds.warning("Add at least one destination object.")
        return
    if not destination_attribute:
        cmds.warning("Specify a destination attribute.")
        return

    source_attr_full = f"{source_object}.{source_attribute}"
    if not cmds.objExists(source_attr_full):
        cmds.error(f"Source attribute {source_attr_full} does not exist.")
        return

    for dest_object in destination_objects:
        dest_attr_full = f"{dest_object}.{destination_attribute}"
        if not cmds.objExists(dest_attr_full):
            cmds.warning(f"Destination attribute {dest_attr_full} does not exist. Skipping.")
            continue
        try:
            cmds.connectAttr(source_attr_full, dest_attr_full, force=True)
            print(f"Connected {source_attr_full} to {dest_attr_full}")
        except Exception as e:
            cmds.warning(f"Failed to connect {source_attr_full} to {dest_attr_full}: {str(e)}")

    cmds.confirmDialog(title="Connection Complete", message="Attributes connected successfully.", button="Close")

create_mass_connection_tool()