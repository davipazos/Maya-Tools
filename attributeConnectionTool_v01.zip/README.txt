#Mass Attribute Connection Tool for Maya

## Overview

This tool provides a user-friendly interface in Maya to connect an attribute from a single source object to multiple destination objects. Perfect for setting up visibility toggles, custom switches, or any other shared behaviors across multiple elements.

## Features

- Select a source object and attribute.
- Select multiple destination objects.
- Connect one attribute to many with a single click.
- Clean and intuitive UI.

## How to Install

1. Download the Script: Get the connectAttributesTool_v01.py file from this Gumroad page.

2. Installation (Recommended for Reuse):
	-Open Maya.
	-Go to Script Editor → Paste the code.
	-Save it to your shelf using File > Save Script to Shelf (Python).

## How to Use

1. Set It Up:

-In the UI that appears:
   	- Select your source object and attribute.
   	- Add one or more destination objects.
   	- Specify the attribute on those objects to connect to.
	- Click "Connect Attributes".
Done!
	-A confirmation will be shown when the connections are made.

## License & Copyright

This script is free to use in personal, student, and commercial projects.

You may share or redistribute it (including modified versions), as long as proper credit is given to the original author.
A link back to the Gumroad page is appreciated when possible.

© 2025 davipazos3d. All rights reserved.

## Contact

Got feedback, questions, or ideas for improvements?
Feel free to reach out via [davipazos3d@gmail.com].